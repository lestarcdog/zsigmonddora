
//refreshCart functionality
(function($) {
  var badge = $("#top-cart #badge");
  var usdTotalPrice = $("#top-cart #total-dollar-price");
  var euroTotalPrice = $("#top-cart #total-euro-price");
  var lineItems = $("#top-cart #cart-item-scroller");
  
  var template = "<div class='row cart-item'><div class='col-xs-6'><img class='img-responsive' src='%%img-url' /></div><div class='col-xs-6'><div class='row'><div class='col-xs-12'><div class='item-title'>%%title</div> <span class='item-price money'>%%usd-price</span> <br \> <div class='item-count'>%%quantity X</div>   </div>                </div>              </div>            </div>";
  
  var createTemplateFrom = function(item) {
   	return template
    	.replace("%%img-url",item.image)
    	.replace("%%title",item.title)
    	.replace("%%usd-price",item.price)
    	.replace("%%quantity",item.quantity);
  }
  
  //add scrolling capability
  lineItems.mCustomScrollbar({
    theme : "light"
   });
  
  var lineItemsContent = lineItems.find(".mCSB_container");
  
  var work = function() {
    $.get("/cart.js",function(data) {
      //console.log(data);

      if(data.item_count > 0) {
      	badge.html(data.item_count);
      } else {
        badge.html("");
      }
            
      
      //clear before add
      lineItemsContent.html("");
      if(data.items.length > 0) {
        //need to remove Currency attributes
        usdTotalPrice.removeAttr("data-currency-usd");
        usdTotalPrice.removeAttr("data-currency-eur");
        usdTotalPrice.removeAttr("data-currency");
        usdTotalPrice.html(data.total_price);
        
      
        $.each(data.items,function(idx,item) {
          var interpolated = createTemplateFrom(item);
          lineItemsContent.append(interpolated);
        });
        
        //format all prices
        MyGlobal.forceFormatCurrencies();
        
      } else {
        lineItemsContent.html("<div class='text-center'>You have no items in your basket</div>");
      }
      
    }, "json");  
  }
  
  MyGlobal.refreshCart = work;
  MyGlobal.refreshCart();
})(jQuery);



//cart a little custom dropdown
//not close on clicking the dropdown area
(function($) {
  $(".dropdown-menu").click(function(evt) {
    evt.stopPropagation();
  });
})(jQuery);