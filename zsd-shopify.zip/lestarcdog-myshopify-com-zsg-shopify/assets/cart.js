
//refreshCart functionality
(function($) {
  var badge = $("#top-cart #badge");
  var usdTotalPrice = $("#top-cart #total-dollar-price");
  var euroTotalPrice = $("#top-cart #total-euro-price");
  var lineItems = $("#top-cart #cart-item-scroller");
  
  var template = "<div class='row cart-item'><div class='col-xs-6'><img class='img-responsive' src='%%img-url' /></div><div class='col-xs-6'><div class='row'>                  <div class='col-xs-12'>                    <span class='item-title'>%%title</span>                     <br />                    <span class='item-price money'>%%usd-price</span>  <br />                    <span class='item-count'>%%quantity</span>X                  </div>                </div>              </div>            </div>";
  
  var createTemplateFrom = function(item) {
   	return template
    	.replace("%%img-url",item.image)
    	.replace("%%title",item.title)
    	.replace("%%usd-price",item.price)
    	.replace("%%quantity",item.quantity);
  }
  
  var work = function() {
    $.get("/cart.js",function(data) {
      //console.log(data);

      if(data.item_count > 0) {
      	badge.html(data.item_count);
      } else {
        badge.html("");
      }
            
      
      //clear before add
      lineItems.html("");
      if(data.items.length > 0) {
        //need to remove Currency attributes
        usdTotalPrice.removeAttr("data-currency-usd");
        usdTotalPrice.removeAttr("data-currency-eur");
        usdTotalPrice.removeAttr("data-currency");
        usdTotalPrice.html(data.total_price);
        
      
        $.each(data.items,function(idx,item) {
          var interpolated = createTemplateFrom(item);
          lineItems.append(interpolated);
        });
        
        //format all prices
        MyGlobal.forceFormatCurrencies();
        
      } else {
        lineItems.html("<div class='text-center'>You have no items in your basket</div>");
      }
      
    }, "json");  
  }
  
  MyGlobal.refreshCart = work;
  MyGlobal.refreshCart();
})(jQuery);



//cart a little custom dropdown
//not close on clicking the dropdown area
(function($) {
  $(".dropdown-menu").click(function(evt) {
    evt.stopPropagation();
  });
})(jQuery);